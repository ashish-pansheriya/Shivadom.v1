from django.contrib import admin
from .models import blogbank

admin.site.register(blogbank)
# Register your models here.

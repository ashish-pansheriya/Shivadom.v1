from django.apps import AppConfig


class CashtreatsConfig(AppConfig):
    name = 'cashtreats'
